
/*
$(document).ready(function(){
	for(var i = 1; i <= 151; i++){
		$(".pokeSelect").append("<img src='http://pokeapi.co/media/img/" + i + ".png' alt='"+i+"'>");
	};

	$(document).on("click", ".pokeSelect img", function(){
		var tempID = $(this).attr("alt");
		$.get("http://pokeapi.co/api/v1/pokemon/" + tempID, function(currentPoke){
			console.log(currentPoke.name);
			var newHTML = "<h2>" + currentPoke.name + "</h2><img src='http://pokeapi.co/media/img/" + tempID + ".png'><h3>Types</h3><ul>";
			var moreHTML = ""
			for(var i = 0; i < currentPoke.types.length; i++){
				moreHTML += "<li>"+currentPoke.types[i].name+"</li>";
			};
			newHTML += moreHTML;
			newHTML += "</ul><h3>Height</h3><p>" + currentPoke.height + "</p><h3>Weight</h3><p>" + currentPoke.weight + "</p>";
			$(".pokeDisplay").html(newHTML);
			console.log(newHTML);
		}, "json");
	});
});
*/
$(document).ready(function() {
    $('form').submit(function() {
        // your code here (build up your url)
        var apiURL = "http://api.openweathermap.org/data/2.5/weather?q=" + $("input[name=city]").val() + "&appid=ceb7be7ea564d604e66ee258802b85c7";
        $.get(apiURL, function(data) {
             console.log(data);
             var tempF = Math.trunc((data.main.temp - 273.15)*1.8 + 32);
             var newHTML = "<h1>" + data.name + "</h1><p>Temperature: " + tempF + "°</p>";
             $("#weatherBox").html(newHTML);
             console.log(newHTML);
        }, 'json');
        // don't forget to return false so the page doesn't refresh
        return false;
    });
});